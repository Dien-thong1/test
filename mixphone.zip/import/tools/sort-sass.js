const fs = require("fs");
const path = require("path");

const propertyOrder = [
  "display",
  "position",
  "top",
  "right",
  "bottom",
  "left",
  "z-index",
  "width",
  "min-width",
  "max-width",
  "height",
  "min-height",
  "max-height",
  "margin",
  "margin-top",
  "margin-right",
  "margin-bottom",
  "margin-left",
  "padding",
  "padding-top",
  "padding-right",
  "padding-bottom",
  "padding-left",
  "border",
  "border-width",
  "border-style",
  "border-color",
  "border-radius",
  "background",
  "background-color",
  "background-image",
  "background-size",
  "background-position",
  "background-repeat",
  "box-shadow",
  "opacity",
  "overflow",
  "overflow-x",
  "overflow-y",
  "color",
  "font",
  "font-size",
  "font-weight",
  "line-height",
  "letter-spacing",
  "text-align",
  "text-decoration",
  "text-transform",
  "white-space",
  "flex",
  "flex-grow",
  "flex-shrink",
  "flex-basis",
  "justify-content",
  "align-items",
  "align-self",
  "gap",
  "grid-template-columns",
  "grid-template-rows",
  "cursor",
  "pointer-events",
  "visibility",
  "user-select",
  "transition",
  "animation",
];

function sortScssProperties(code) {
  const lines = code.split(/\r?\n/);
  const stack = [];
  const output = [];
  let buffer = [];
  const isProperty = (line) =>
    line.includes(":") &&
    !line.trim().startsWith("@") &&
    !line.trim().startsWith("//") &&
    !line.trim().startsWith("$") &&
    !line.includes("{") &&
    !line.includes("}");

  function flushBuffer() {
    if (buffer.length === 0) return;
    const props = buffer.map((line) => {
      const [key, ...rest] = line.split(":");
      return { raw: line, key: key.trim(), value: rest.join(":").trim() };
    });
    const ordered = [];
    const rest = [];
    for (const prop of props) {
      const index = propertyOrder.indexOf(prop.key);
      if (index >= 0) ordered[index] = prop;
      else rest.push(prop);
    }
    const final = [...ordered.filter(Boolean), ...rest];
    for (let p of final) output.push(p.raw);
    buffer = [];
  }

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.endsWith("{")) {
      flushBuffer();
      output.push(line);
    } else if (trimmed === "}") {
      flushBuffer();
      output.push(line);
    } else if (isProperty(line)) {
      buffer.push(line);
    } else {
      flushBuffer();
      output.push(line);
    }
  }

  flushBuffer();
  return output.join("\n");
}

function processScssFilesInDir(dirPath) {
  const absDir = path.resolve(dirPath);
  if (!fs.existsSync(absDir)) {
    console.error(`❌ Thư mục không tồn tại: ${absDir}`);
    process.exit(1);
  }

  const files = fs.readdirSync(absDir, { withFileTypes: true });

  for (const file of files) {
    const fullPath = path.join(absDir, file.name);
    if (file.isDirectory()) {
      processScssFilesInDir(fullPath); // đệ quy nếu là thư mục
    } else if (file.isFile() && file.name.endsWith(".scss")) {
      const raw = fs.readFileSync(fullPath, "utf-8");
      const sorted = sortScssProperties(raw);
      fs.writeFileSync(fullPath, sorted);
      console.log(`✅ Đã sắp xếp: ${fullPath}`);
    }
  }
}

processScssFilesInDir("./sass");
