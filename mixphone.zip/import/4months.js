const csl = console.log;
const eso = JSON.stringify;
const dso = JSON.parse;

const FM = {
  s(element) {
    return document.querySelector(element);
  },
  click: (element, func, deep = true) => {
    if (typeof element === "string") {
      element = document.querySelector(element);
    }

    element.addEventListener("click", (event) => {
      if (deep) {
        func(event);
      } else {
        if (event.target === element) {
          func(event);
        }
      }
    });
  },

  runFrame: (func) => {
    const f = () => {
      func();
      requestAnimationFrame(f);
    };
    f();
  },

  sync: (varNameA, varNameB, func) => {
    const handler = {
      set(target, key, value) {
        if (target[key] === value) return true;

        target[varNameA] = value;
        target[varNameB] = value;

        window[varNameA] = value;
        window[varNameB] = value;

        func();
        return true;
      },
    };
    const proxy = new Proxy(
      { [varNameA]: window[varNameA], [varNameB]: window[varNameB] },
      handler,
    );

    [varNameA, varNameB].forEach((name) => {
      Object.defineProperty(window, name, {
        get: () => proxy[name],
        set: (val) => {
          proxy[name] = val;
        },
        configurable: true,
      });
    });
  },

  toggle: (count, funcs, call = false) => {
    if (!Array.isArray(funcs)) return;
    if (typeof call === "number") {
      const fn = funcs[call - 1];
      if (typeof fn === "function") fn();
      window["_toggle_" + count + "_"] = call;
      return;
    }
    if (typeof window["_toggle_" + count + "_"] !== "number")
      window["_toggle_" + count + "_"] = 0;
    window["_toggle_" + count + "_"] =
      (window["_toggle_" + count + "_"] % funcs.length) + 1;
    const fn = funcs[window["_toggle_" + count + "_"] - 1];
    if (typeof fn === "function") fn();
  },
  resize: (func) => {
    window.addEventListener("resize", func);
  },
  api: {
    load: (url, takewar, func) => {
      fetch(url)
        .then((res) => res.text())
        .then((data) => {
          window[takewar] = data;
          func();
        });
    },
    ls: (key, text) => {
      if (typeof text !== "undefined") {
        localStorage.setItem(key, text);
      } else {
        return localStorage.getItem(key);
      }
    },
    lsuo: (key) => {
      const raw = localStorage.getItem(key);
      let data = raw ? JSON.parse(raw) : {};
      const save = () => {
        localStorage.setItem(key, JSON.stringify(data));
      };
      const wrap = (obj) => {
        if (obj !== Object(obj)) return obj;
        return new Proxy(obj, {
          get(target, prop, receiver) {
            const value = Reflect.get(target, prop, receiver);
            return typeof value === "object" && value !== null
              ? wrap(value)
              : value;
          },
          set(target, prop, value, receiver) {
            const result = Reflect.set(target, prop, value, receiver);
            save();
            return result;
          },
          deleteProperty(target, prop) {
            const result = Reflect.deleteProperty(target, prop);
            save();
            return result;
          },
        });
      };
      return wrap(data);
    },
  },
  array: {
    f09: (arr) => {
      return [...arr].sort((a, b) => a - b);
    },
    f90: (arr) => {
      return [...arr].sort((a, b) => b - a);
    },
    deSame: (arr) => {
      return [...new Set(arr)];
    },
    findKey: (arr, key, value) => {
      return arr.find((item) => item[key] === value);
    },
    findMC: (array, criteria) => {
      return array.find((obj) =>
        Object.entries(criteria).every(([key, value]) => obj[key] === value),
      );
    },
    check: (arr, value, data = true) => {
      if (data === true) {
        return arr.some((item) => {
          if (Array.isArray(item) && Array.isArray(value)) {
            return (
              item.length === value.length &&
              item.every((v, i) => v === value[i])
            );
          }
          return item === value;
        });
      } else if (data === 0) {
        return arr.findIndex((item) => {
          if (Array.isArray(item) && Array.isArray(value)) {
            return (
              item.length === value.length &&
              item.every((v, i) => v === value[i])
            );
          }
          return item === value;
        });
      }
    },
    deDup: (main, remove) => {
      const isEqual = (a, b) => {
        if (Array.isArray(a) && Array.isArray(b)) {
          return a.length === b.length && a.every((v, i) => v === b[i]);
        }
        return a === b;
      };
      return main.filter(
        (item1) => !remove.some((item2) => isEqual(item1, item2)),
      );
    },
    remove: (arr, value, all = false) => {
      function isEqual(a, b) {
        if (Array.isArray(a) && Array.isArray(b)) {
          if (a.length !== b.length) return false;
          return a.every((v, i) => isEqual(v, b[i]));
        }
        return a === b;
      }
      if (all) {
        return arr.filter((item) => !isEqual(item, value));
      } else {
        for (let i = 0; i < arr.length; i++) {
          if (isEqual(arr[i], value)) {
            arr.splice(i, 1);
            break;
          }
        }
        return arr;
      }
    },
    ranPercent: (arr, percent) => {
      const count = Math.floor((percent / 100) * arr.length);
      const shuffled = arr.slice().sort(() => Math.random() - 0.5);
      return shuffled.slice(0, count);
    },
    maxKey: (obj, random = true) => {
      const maxVal = Math.max(...Object.values(obj));
      const topKeys = Object.keys(obj).filter((k) => obj[k] === maxVal);
      return random
        ? topKeys[Math.floor(Math.random() * topKeys.length)]
        : topKeys[0];
    },
    minKey: (obj, random = true) => {
      const minVal = Math.min(...Object.values(obj));
      const bottomKeys = Object.keys(obj).filter((k) => obj[k] === minVal);
      return random
        ? bottomKeys[Math.floor(Math.random() * bottomKeys.length)]
        : bottomKeys[0];
    },
    maxValue: (obj) => {
      return Math.max(...Object.values(obj));
    },
    minValue: (obj) => {
      return Math.min(...Object.values(obj));
    },
  },

  obj: {
    for: (obj, callback) => {
      Object.keys(obj).forEach((key) => {
        callback(key, obj[key]);
      });
    },
    fmObj: (key, objNames, objReal = false) => {
      for (let name of objNames) {
        const obj = window[name];
        if (obj && typeof obj === "object" && obj.hasOwnProperty(key)) {
          return objReal ? obj : name;
        }
      }
      return null;
    },
    path: (obj, target, all = false) => {
      if (typeof obj !== "object" || obj === null) return all ? [] : null;
      const match = (o, t) =>
        Object.keys(t).every((k) => k in o && (t[k] === null || o[k] === t[k]));
      const stack = [{ current: obj, path: [] }];
      const results = [];
      while (stack.length) {
        const { current, path } = stack.pop();
        if (match(current, target)) {
          if (!all) return path;
          results.push(path);
        }
        for (const k in current) {
          const v = current[k];
          if (v && typeof v === "object")
            stack.push({ current: v, path: [...path, k] });
        }
      }
      return all ? results : undefined;
    },
    toArr: (obj) => {
      return Object.values(obj);
    },
    f90: (obj) => {
      return Object.fromEntries(
        Object.entries(obj).sort((a, b) => b[1] - a[1]),
      );
    },
    f09: (obj) => {
      return Object.fromEntries(
        Object.entries(obj).sort((a, b) => a[1] - b[1]),
      );
    },
    idxKey: (obj, tt = 0) => {
      return Object.keys(obj)[tt];
    },
    deKey: (obj, tt) => {
      delete obj[Object.keys(obj)[tt]];
    },
    maxKey: (obj) => {
      const maxVal = Math.max(...Object.values(obj));
      const topKeys = Object.keys(obj).filter((k) => obj[k] === maxVal);
      return topKeys[Math.floor(Math.random() * topKeys.length)];
    },
    maxValue: (obj) => {
      return Math.max(...Object.values(obj));
    },
  },

  random: {
    number: (from, to, rounding = true) => {
      const range = to - from;
      return rounding
        ? Math.floor(Math.random() * (range + 1)) + from
        : Math.random() * range + from;
    },
    string: (charset, length) => {
      return Array.from(
        { length },
        () => charset[Math.floor(Math.random() * charset.length)],
      ).join("");
    },
    oneIn: (max) => {
      return Math.floor(Math.random() * max) + 1 === 1;
    },
    array: (arr, count = 1, allowDuplicates = true) => {
      if (!Array.isArray(arr)) return [];
      const result = [];
      if (allowDuplicates) {
        for (let i = 0; i < count; i++) {
          result.push(arr[Math.floor(Math.random() * arr.length)]);
        }
      } else {
        const shuffled = arr.slice().sort(() => 0.5 - Math.random());
        return shuffled.slice(0, Math.min(count, arr.length));
      }
      return count === 1 ? result[0] : result;
    },
  },
  firebase: {
    write: (path, content) => {
      firebase.database().ref(path).set(content);
    },

    remove: (path) => {
      firebase.database().ref(path).remove();
    },

    read: (path, namevar, func) => {
      firebase
        .database()
        .ref(path)
        .once("value")
        .then((snapshot) => {
          window[namevar] = snapshot.val();
          func();
        });
    },

    reads: (path, namevar, func) => {
      firebase
        .database()
        .ref(path)
        .on("value", (snapshot) => {
          window[namevar] = snapshot.val();
          func();
        });
    },
  },
  dom: {
    isChild: (child, parent) => {
      if (typeof child === "string") {
        child = document.querySelector(child);
      }
      if (typeof parent === "string") {
        parent = document.querySelector(parent);
      }
      if (!child || !parent) return false;
      return parent.contains(child);
    },

    type: (element, type, value) => {
      let el = element;
      if (typeof element === "string") {
        el = document.querySelector(element);
      }
      if (value !== undefined) {
        el.setAttribute(type, value);
      } else {
        return el.getAttribute(type);
      }
    },

    create: (tag, add) => {
      var el = document.createElement(tag);
      var parent = add;
      if (typeof add === "string") {
        parent = document.querySelector(add);
      }
      parent.appendChild(el);
      return el;
    },

    remove: (element) => {
      let el = element;
      if (typeof element === "string") {
        el = document.querySelector(element);
      }
      el.remove();
    },

    creates: (tag, add, config) => {
      var el = document.createElement(tag);
      var parent = add;
      if (typeof add === "string") {
        parent = document.querySelector(add);
      }
      parent.appendChild(el);

      if (typeof config === "object") {
        for (const key in config) {
          if (key === "dom") {
            window[config[key]] = el;
          } else if (key === "html") {
            el.innerHTML = config[key];
          } else if (key === "text") {
            el.innerText = config[key];
          } else if (key === "id") {
            el.id = config[key];
          } else if (key === "class") {
            config[key].split(" ").forEach((cls) => el.classList.add(cls));
          } else if (key === "onclick" || key === "click") {
            el.addEventListener("click", config[key]);
          } else if (key === "style" && typeof config.style === "object") {
            Object.assign(el.style, config.style);
          } else {
            el.setAttribute(key, config[key]);
          }
        }
      }
      return el;
    },

    select: (element, config) => {
      let el = element;
      if (typeof element === "string") {
        el = document.querySelector(element);
      }

      if (typeof config === "object") {
        for (const key in config) {
          if (key === "dom") {
            window[config[key]] = el;
          } else if (key === "html") {
            el.innerHTML = config[key];
          } else if (key === "text") {
            el.innerText = config[key];
          } else if (key === "id") {
            el.id = config[key];
          } else if (key === "class") {
            el.classList.add(config[key]);
          } else if (key === "onclick" || key === "click") {
            el.addEventListener("click", config[key]);
          } else if (key === "style" && typeof config.style === "object") {
            Object.assign(el.style, config.style);
          } else {
            el.setAttribute(key, config[key]);
          }
        }
      }
      return el;
    },
  },
  format: {
    fmc: (number) => {
      return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    },
  },
};
