function f_comment(post_id, user_name) {
  FM.s(".page_comment").style.transform = "translateY(0%)";
  FM.api.load(
    "http://localhost:3000/php/comment.php?post_id=" + post_id,
    "loaded",

    () => {
      loaded = JSON.parse(loaded);

      FM.s(".page_comment .title").innerHTML = "Bài viết của " + user_name;

      let temp_html = "";

      loaded.forEach((con) => {
        temp_html += `
  
          <div class="comment comment_${con.comment_id}">
          <div class="t1">
            <span class="user_name name_profile">${con.user_name}</span>
            <span class="date_time">${con.created_at}</span>
          </div>

          <div class="user_comment">${con.content}</div>
          <div class="feedback">
            <span>
              <button onclick="f_comment_1(${con.comment_id})" class="more ${con.feedback_count < 1 ? "hide" : ""}">Xem ${con.feedback_count} phản hồi</button>
              <span class="like_count ${con.like_count < 1 ? "hide" : ""}">❤️ ${con.like_count}</span>
            </span>
            <span>
              <button class="reply">💬 Trả lời</button>
              <button class="like ${con.is_liked === 1 ? "liked" : ""}" onclick="commentLike(this, ${con.comment_id})">${con.is_liked === 1 ? "❤️" : "🤍"} Thích</button>
            </span>
          </div>
        </div>

  `;
      });

      FM.s(".page_comment .box").innerHTML = temp_html;
    },
  );
}

FM.click(".page_comment .close", () => {
  if (FM.s(".page_comment_1").style.opacity === "1") {
    FM.s(".page_comment_1").style.opacity = "0";
    FM.s(".page_comment_1").style.pointerEvents = "none";
  } else {
    FM.s(".page_comment").style.transform = "translateY(100%)";
  }
});

function f_comment_1(comment_id) {
  FM.s(".page_comment_1").style.opacity = "1";
  FM.s(".page_comment_1").style.pointerEvents = "auto";

  FM.s(".page_comment_1").innerHTML = FM.s(".comment_" + comment_id).outerHTML;
  FM.s(".page_comment_1").innerHTML += `
  <div class="box_1">
  </div>

  `;

  FM.api.load(
    "http://localhost:3000/php/comment_1.php?parent_id=1",
    "loaded",

    () => {
      loaded = JSON.parse(loaded);

      let temp_html = "";

      loaded.forEach((con) => {
        temp_html += `
  
          <div class="comment comment_${con.comment_id}">
          <div class="t1">
            <span class="user_name name_profile">${con.user_name}</span>
            <span class="date_time">${con.created_at}</span>
          </div>

          <div class="user_comment">${con.content}</div>
          <div class="feedback">
            <span>
              <button onclick="f_comment_1(${con.comment_id})" class="more ${con.feedback_count < 1 ? "hide" : ""}">Xem ${con.feedback_count} phản hồi</button>
              <span class="like_count ${con.like_count < 1 ? "hides" : ""}">❤️ ${con.like_count}</span>
            </span>
            <span>
              <button class="reply">💬 Trả lời</button>
              <button class="like ${con.is_liked === 1 ? "liked" : ""}" onclick="commentLike(this, ${con.comment_id})">${con.is_liked === 1 ? "❤️" : "🤍"} Thích</button>
            </span>
          </div>
        </div>

  `;
      });

      csl(loaded);

      FM.s(".box_1").innerHTML += temp_html;
    },
  );
}

function commentLike(eleThis, commentId) {
  let like;
  if (eleThis.classList.contains("liked")) {
    eleThis.classList.remove("liked");
    eleThis.innerHTML = "🤍 Thích";
    like = 0;
  } else {
    eleThis.classList.add("liked");
    eleThis.innerHTML = "❤️ Thích";
    like = 1;
  }
  FM.api.load(
    `http://localhost:3000/php/comment_like.php?comment_id=${commentId}&user_id=26062006&like=${like}`,
    "loaded",
    () => {
      if (FM.dom.isChild(eleThis, ".page_comment")) {
        FM.s(`.comment_${commentId} .like_count`).innerHTML = "❤️ " + loaded;
      }
      if (FM.dom.isChild(eleThis, ".page_comment_1")) {
        FM.s(`.page_comment_1 .comment_${commentId} .like_count`).innerHTML =
          "❤️ " + loaded;

        if (eleThis.classList.contains("liked")) {
          FM.s(".box .like").classList.add("liked");
          FM.s(".box .like").innerHTML = "❤️ Thích";
        } else {
          FM.s(".box .like").classList.remove("liked");
          FM.s(".box .like").innerHTML = "🤍 Thích";
        }
        if (FM.dom.isChild(eleThis, ".box_1")) {
          if (eleThis.classList.contains("liked")) {
            FM.s(".commnent_4 .like").classList.add("liked");
            FM.s(".commnent_4 .like").innerHTML = "❤️ Thích";
          } else {
            FM.s(".commnent_4 .like").classList.remove("liked");
            FM.s(".commnent_4 .like").innerHTML = "🤍 Thích";
          }
        }
      }
    },
  );
}
