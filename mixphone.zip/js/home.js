function pageHome() {
  FM.api.load("/php/post.php", "loaded", () => {
    loaded = JSON.parse(loaded);

    FM.s(".page_home").innerHTML = "";

    temp_html = "";

    loaded.forEach((post) => {
      temp_html_1 = "";

      JSON.parse(post.tag).forEach((tag) => {
        temp_html_1 += `<span>#${tag}</span>`;
      });

      temp_html += `
        
<div class="post_${post.type} post_${post.post_id}">
  <div class="name name_profile">    ${post.user_name}</div> <span class="created_at date_time">
  01/01/2000</span>
  <div class="tag">
     ${temp_html_1}
  </div>
  <div class="content" onclick="showPagePost(${post.post_id})">
    ${post.content}
  </div>
  
${
  post.type === "basic"
    ? `
  <div class="image">
    <img src="/image/icon/${post.image}.jpg" alt="" />
  </div>
  `
    : ""
}

${
  post.type === "sell"
    ? `
  <div class="price">${FM.format.fmc(post.price)}</div>    
  <button class="buy">Liên hệ</button>
  <div class="image">
    <img src="/image/icon/${post.image}.jpg" alt="" />
  </div>

  `
    : ""
}

${
  post.type === "poll"
    ? `
  <div class="poll">
    <div class="options">iPhone 14 Pro Max</div>
    <div class="options">iPhone 15 Plus</div>
  </div>

  `
    : ""
}

  <div class="interact">
    <button class="like ${post.is_liked === 1 ? "liked" : ""} ${post.total_likes}" onclick="postLike(this,${post.post_id})">${post.is_liked === 1 ? "❤️" : "🤍"} ${post.total_likes}</button>
    <button onclick="f_comment(${post.post_id}, '${post.user_name}')">💬 ${post.total_comments}</button>

  </div>
  <div class="more"></div>
</div>

        `;
    });

    FM.s(".page_home").innerHTML = temp_html;
  });
}

function showPagePost(post_id) {
  FM.s(".page_post").style.transform = "translateX(0)";
  FM.s(".page_post").style.opacity = "1";
  f_page_post(post_id);
}
function hidePagePost(x) {
  FM.s(".page_post").style.transform = "translateX(-100%)";
  FM.s(".page_post").style.opacity = "0";
}

userIdTest = FM.random.number(10000000, 99999999, true);
