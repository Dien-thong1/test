function oo_menu(call = true) {
  FM.toggle(
    "oo_menu",
    [
      () => {
        FM.s(".k2 ").style.opacity = "1";
        FM.s(".k2 ").style.pointerEvents = "auto";
        FM.s(".k2 .tab_menu").style.transform = "translateX(100%)";
        csl("a");
      },
      () => {
        FM.s(".k2 ").style.opacity = "0";
        FM.s(".k2 ").style.pointerEvents = "none";
        FM.s(".k2 .tab_menu").style.transform = "translateX(0%)";
        csl("b");
      },
    ],
    call,
  );
}

FM.click(".button_menu", () => {
  oo_menu();
});
FM.click(".k2", () => {
  oo_menu(2);
});

FM.api.load("/html/home.html", "loaded", () => {
  FM.s(".page_home").innerHTML = loaded;
  FM.s(".page_home").style.zIndex = 2;
  FM.s(".page_chat").style.zIndex = 1;

  pageHome();
});

FM.api.load("/html/chat.html", "html_load_chat", () => {
  FM.s(".page_chat").innerHTML = html_load_chat;
});

FM.click(".in_home", () => {
  FM.s(".page_home").style.opacity = 1;
  FM.s(".page_chat").style.opacity = 0;
});
FM.click(".in_chat", () => {
  FM.s(".page_home").style.opacity = 0;
  FM.s(".page_chat").style.opacity = 1;
});

document.querySelector();
function postLike(eleThis, postId) {
  let like;
  if (eleThis.classList.contains("liked")) {
    eleThis.classList.remove("liked");
    eleThis.innerHTML = "🤍 ";
    like = 0;
  } else {
    eleThis.classList.add("liked");
    eleThis.innerHTML = "❤️ ";
    like = 1;
  }

  FM.api.load(
    `/php/post_like.php?post_id=${postId}&user_id=${userIdTest}&like=${like}`,
    "loaded",
    () => {
      eleThis.innerHTML += loaded;

      if (FM.dom.isChild(eleThis, ".page_post")) {
        FM.s(`.page_home .post_${postId} .like`).outerHTML = FM.s(
          `.page_post .post_${postId} .like`,
        ).outerHTML;
      }
    },
  );
  csl(1);
}
