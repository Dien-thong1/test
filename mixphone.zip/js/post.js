function f_page_post(post_id) {
  FM.s(`.page_post`).innerHTML = FM.s(`.post_${post_id}`).outerHTML;

  let theA = FM.s(`.page_home .post_${post_id} .like`);
  let theB = FM.s(`.page_post .post_${post_id} .like`);

  FM.click(`.page_post .more`, () => {
    hidePagePost();
  });
}
