<?php
$host    = 'localhost';
$db_name = 'chip_thu';
$user    = 'root';
$pass    = '';
$charset = 'utf8mb4';

// ID của người đang xem để kiểm tra xem họ đã Like bài viết chưa
$current_user_id = 26062006; 

$dsn = "mysql:host=$host;dbname=$db_name;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);

    $sql = "SELECT 
                p.*, 
                u.user_name,
                -- 1. Đếm số lượt thích từ bảng post_likes
                (SELECT COUNT(*) FROM post_likes WHERE post_id = p.post_id) AS total_likes,
                -- 2. Kiểm tra xem user hiện tại đã like chưa
                (SELECT COUNT(*) FROM post_likes WHERE post_id = p.post_id AND user_id = :current_user) AS is_liked,
                -- 3. Đếm tổng số bình luận của bài viết này
                (SELECT COUNT(*) FROM comment WHERE post_id = p.post_id) AS total_comments
            FROM post p
            INNER JOIN user u ON p.user_id = u.user_id
            ORDER BY p.created_at DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['current_user' => $current_user_id]);
    $data = $stmt->fetchAll();

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(["error" => "Lỗi: " . $e->getMessage()]);
}