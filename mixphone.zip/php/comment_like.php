<?php
$host    = 'localhost';
$db_name = 'chip_thu';
$user    = 'root';
$pass    = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    // Lấy thông tin từ URL
    $comment_id = $_GET['comment_id'] ?? null;
    $user_id    = $_GET['user_id'] ?? null;
    $is_like    = $_GET['like'] ?? null; 

    if ($comment_id && $user_id && $is_like !== null) {
        
        if ($is_like == 1) {
            // Thêm lượt thích vào bảng comment_likes
            $sql = "INSERT IGNORE INTO comment_likes (comment_id, user_id, created_at) VALUES (:comment_id, :user_id, NOW())";
        } else {
            // Xóa lượt thích
            $sql = "DELETE FROM comment_likes WHERE comment_id = :comment_id AND user_id = :user_id";
        }
        
        $pdo->prepare($sql)->execute(['comment_id' => $comment_id, 'user_id' => $user_id]);

        // Đếm lại tổng số lượt like của bình luận này để trả về cho Frontend cập nhật giao diện
        $stmt_count = $pdo->prepare("SELECT COUNT(*) as total FROM comment_likes WHERE comment_id = :comment_id");
        $stmt_count->execute(['comment_id' => $comment_id]);
        $total = $stmt_count->fetchColumn();

        header('Content-Type: application/json');
        echo $total;
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}