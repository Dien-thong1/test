<?php
$host    = 'localhost';
$db_name = 'chip_thu';
$user    = 'root';
$pass    = '';
$charset = 'utf8mb4';

// Lấy post_id và user_id (để kiểm tra xem user đó đã like chưa)
$post_id = isset($_GET['post_id']) ? intval($_GET['post_id']) : 0;

$viewer_id = 26062006;

$dsn = "mysql:host=$host;dbname=$db_name;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);

    $sql = "SELECT 
                c.comment_id, 
                c.post_id, 
                c.user_id, 
                c.parent_id, 
                c.content, 
                c.created_at,
                u.user_name,
                -- 1. Đếm số lượng phản hồi (feedback)
                (SELECT COUNT(*) FROM comment WHERE parent_id = c.comment_id) AS feedback_count,
                -- 2. Đếm số lượt thích (likes) từ bảng comment_likes
                (SELECT COUNT(*) FROM comment_likes WHERE comment_id = c.comment_id) AS like_count,
                -- 3. Kiểm tra xem người đang xem đã like comment này chưa (1: rồi, 0: chưa)
                (SELECT COUNT(*) FROM comment_likes WHERE comment_id = c.comment_id AND user_id = :viewer_id) AS is_liked
            FROM comment c
            INNER JOIN user u ON c.user_id = u.user_id
            WHERE c.post_id = :post_id 
              -- Thay đổi: Chỉ lấy những comment có parent_id là 0 (Comment cha)
              AND (c.parent_id = 0) 
            ORDER BY c.created_at DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'post_id'   => $post_id,
        'viewer_id' => $viewer_id
    ]);
    $comments = $stmt->fetchAll();

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($comments, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(["error" => "Lỗi: " . $e->getMessage()]);
}