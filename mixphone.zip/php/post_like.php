<?php

// header("Access-Control-Allow-Origin: *");
// header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
// header("Access-Control-Allow-Headers: Content-Type");

$host    = 'localhost';
$db_name = 'chip_thu';
$user    = 'root';
$pass    = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    $post_id = $_GET['post_id'] ?? null;
    $user_id = $_GET['user_id'] ?? null;
    $is_like = $_GET['like'] ?? null; 

    if ($post_id && $user_id && $is_like !== null) {
        
        if ($is_like == 1) {
            $sql = "INSERT IGNORE INTO post_likes (post_id, user_id, created_at) VALUES (:post_id, :user_id, NOW())";
        } else {
            $sql = "DELETE FROM post_likes WHERE post_id = :post_id AND user_id = :user_id";
        }
        
        $pdo->prepare($sql)->execute(['post_id' => $post_id, 'user_id' => $user_id]);

        $stmt_count = $pdo->prepare("SELECT COUNT(*) as total FROM post_likes WHERE post_id = :post_id");
        $stmt_count->execute(['post_id' => $post_id]);
        $total = $stmt_count->fetchColumn();

        header('Content-Type: application/json');
        echo $total;

    }
} catch (PDOException $e) {
    echo json_encode(["status" => "error"]);
}