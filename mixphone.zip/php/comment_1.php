<?php
$host    = 'localhost';
$db_name = 'chip_thu';
$user    = 'root';
$pass    = '';
$charset = 'utf8mb4';

// Giả định ID người dùng đang xem (nên lấy từ Session hoặc $_GET tương tự comment.php)
$viewer_id = 26062006; 

$dsn = "mysql:host=$host;dbname=$db_name;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

$parent_id = isset($_GET['parent_id']) ? intval($_GET['parent_id']) : 0;

try {
    $pdo = new PDO($dsn, $user, $pass, $options);

    $sql = "SELECT 
                c.comment_id, 
                c.post_id, 
                c.user_id, 
                c.parent_id, 
                c.content, 
                c.created_at,
                u.user_name,
                -- 1. Đếm số lượng phản hồi cấp sâu hơn (nếu có)
                (SELECT COUNT(*) FROM comment WHERE parent_id = c.comment_id) AS feedback_count,
                -- 2. Đếm số lượt thích của chính phản hồi này
                (SELECT COUNT(*) FROM comment_likes WHERE comment_id = c.comment_id) AS like_count,
                -- 3. Kiểm tra xem người xem đã like phản hồi này chưa
                (SELECT COUNT(*) FROM comment_likes WHERE comment_id = c.comment_id AND user_id = :viewer_id) AS is_liked
            FROM comment c
            INNER JOIN user u ON c.user_id = u.user_id
            WHERE c.parent_id = :parent_id 
            ORDER BY c.created_at ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'parent_id' => $parent_id,
        'viewer_id' => $viewer_id
    ]);
    $replies = $stmt->fetchAll();

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($replies, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(["error" => "Lỗi: " . $e->getMessage()]);
}
?>