sass --watch sass/:css/
